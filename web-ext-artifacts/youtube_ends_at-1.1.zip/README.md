# youtube-ends-at
A simple webextension to display when a youtube video will end
