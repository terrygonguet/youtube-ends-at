# youtube-ends-at

A simple webextension to display when a youtube video will end

Add-on stores:

-   [Chrome, Opera, Edge, Brave etc.](https://chrome.google.com/webstore/detail/youtube-ends-at/oahgfgokmkpgkbfnedkbbmnogjmfpljd)
-   [Firefox](https://addons.mozilla.org/en-US/firefox/addon/youtube-ends-at/)
